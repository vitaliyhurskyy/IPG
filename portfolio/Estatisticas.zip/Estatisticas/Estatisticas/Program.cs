﻿using System;

namespace Estatisticas
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = LeQuantidadeNumeros();
            double[] valores = new double[n];
            int[] quantasVezesNumeroApareceu = new int[n];

            for (int i = 0; i < n; i++)
            {
                valores[i] = LeNumero($"Introduza o {i + 1} valor:");
            }

            double min = double.MaxValue;
            double max = double.MinValue;
            double moda = 0; // não interessa o valor (porque vai ser substituido)
            int numeroVezesModaApareceu = 0;

            double soma = 0.0;
            for (int i = 0; i < n; i++)
            {
                double v = valores[i];

                soma += v;

                if (v < min)
                {
                    min = valores[i];
                }

                if (v > max)
                {
                    max = valores[i];
                }

                int numeroVezesApareceu = 0;
                for (int j = i - 1; j >= 0; j--)
                {
                    if (valores[j] == v)
                    {
                        numeroVezesApareceu = quantasVezesNumeroApareceu[j];
                        break;
                    }
                }

                numeroVezesApareceu++;
                quantasVezesNumeroApareceu[i] = numeroVezesApareceu;

                if (numeroVezesModaApareceu < numeroVezesApareceu)
                {
                    moda = v;
                    numeroVezesModaApareceu = numeroVezesApareceu;
                }
            }
           
            //                         i
            //                   j    
            // valores = 1 2 3 8 3 2 1 3
            // qvna    = 1 1 1 1 2 2 2 3

            Console.WriteLine($"Mínimo: {min}");
            Console.WriteLine($"Máximo: {max}");
            Console.WriteLine($"Moda  : {moda}");
            Console.WriteLine($"Média : {soma / n:0.##}");
        }

        private static double LeNumero(string mensagem)
        {
            while(true)
            {
                Console.WriteLine(mensagem);
                try
                {
                    string s = Console.ReadLine();
                    return double.Parse(s);
                }
                catch (Exception)
                {
                    Console.WriteLine("Introduza um número válido");
                }
            }
        }

        private static int LeQuantidadeNumeros()
        {
            while (true)
            {
                Console.WriteLine("Quantos números pretende introduzir");
                try
                {
                    string s = Console.ReadLine();
                    int n = int.Parse(s);
                    if (n > 0)
                    {
                        return n;
                    } else
                    {
                        Console.WriteLine("A quantidade de números deve ser maior que zero.");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Introduza um número válido");
                }
            }
        }
    }
}
