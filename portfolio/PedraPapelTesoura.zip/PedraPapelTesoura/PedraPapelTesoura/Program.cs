﻿using System;
using System.Drawing;

namespace PedraPapelTesoura
{
    class Program
    {
        private const int PEDRA = 1;
        private const int PAPEL = 2;
        private const int TESOURA = 3;
        private const int SAIR = 9;

        static string PedraPapelTesoura(int valor)
        {
            switch (valor)
            {
                case PEDRA:
                    return "Pedra";

                case PAPEL:
                    return "Papel";

                case TESOURA:
                    return "Tesoura";
            }

            return null;
        }

        static void Main(string[] args)
        {
            Random random = new Random();

            Console.WriteLine("Indique o seu nome:");
            string nome = Console.ReadLine();

            if (nome.Trim() == "")
            {
                nome = "ANÓNIMO";
            }

            int pontosJogador = 0;
            int pontosComputador = 0;

            bool estaJogar = true;
            while (estaJogar)
            {
                int escolhaJogador = LeOpcaoMenu();
                if (escolhaJogador == SAIR)
                {
                    estaJogar = false;
                }
                else
                {
                    int escolhaComputador = random.Next(1, 4);

                    Console.WriteLine($"Você escolheu {PedraPapelTesoura(escolhaJogador)}. Eu (computador) escolhi {PedraPapelTesoura(escolhaComputador)}.");

                    if (escolhaJogador == escolhaComputador)
                    {
                        Console.WriteLine("EMPATE");
                    }
                    else
                    {
                        bool ganhouJogador = false;

                        switch(escolhaJogador)
                        {
                            case PEDRA:
                                ganhouJogador = (escolhaComputador == TESOURA);
                                break;

                            case PAPEL:
                                ganhouJogador = (escolhaComputador == PEDRA);
                                break;

                            case TESOURA:
                                ganhouJogador = (escolhaComputador == PAPEL);
                                break;
                        }

                        if (ganhouJogador)
                        {
                            pontosJogador++;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Bolas. Você ganhou o jogo.");
                        } else
                        {
                            pontosComputador++;
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine(":). Ganhei. Campeão !!!");
                        }

                        Console.ResetColor();
                    }
                }
                Console.WriteLine("\nPontuação atual");
                Console.WriteLine($"{nome}: {pontosJogador} | COMPUTADOR: {pontosComputador}");
            }
        }

        private static int LeOpcaoMenu()
        {
            while (true)
            {
                Console.WriteLine("\n\nMenu");
                Console.WriteLine($"({PEDRA}) Pedra");
                Console.WriteLine($"({PAPEL}) Papel");
                Console.WriteLine($"({TESOURA}) Tesoura");
                Console.WriteLine($"({SAIR}) Sair");

                string s = Console.ReadLine();
                int opcao = int.Parse(s);

                switch (opcao)
                {
                    case PEDRA:
                    case PAPEL:
                    case TESOURA:
                    case SAIR:
                        return opcao;

                    default:
                        Console.WriteLine("Opção Inválida");
                        break;
                }
            }
        }
    }
}
