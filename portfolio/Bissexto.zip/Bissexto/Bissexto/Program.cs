﻿using System;

namespace Bissexto
{
    class Program
    {
        static bool Bissexto(int ano)
        {
            if (ano % 4 != 0) return false;
            if (ano % 400 == 0) return true;

            if (ano % 100 != 0) return true;
            return false;

            //return ano % 100 != 0;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Determinar se um ano é bissexto");

            Console.WriteLine("Introduza o ano:");
            string s = Console.ReadLine();
            int ano = int.Parse(s);

            if (Bissexto(ano))
            {
                Console.WriteLine($"{ano} é bissexto");
            } else
            {
                Console.WriteLine($"{ano} não é bissexto");
            }

            Console.ReadKey();
        }
    }
}
