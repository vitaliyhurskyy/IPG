﻿using System;

namespace Fibonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Serie de Fibonacci");

            Console.WriteLine("Quantos termos pretende mostrar");
            string s = Console.ReadLine();
            int n = int.Parse(s);

            if (n > 0) {
                Console.Write("0");
            }

            if (n > 1)
            {
                Console.Write(", 1");
            }

            int penultimo = 0;
            int ultimo = 1;

            for (int i = 3; i <= n; i++)
            {
                int atual = ultimo + penultimo;
                Console.Write($", {atual}");
                penultimo = ultimo;
                ultimo = atual;
            }

            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
